import Assignment03.{Q01, Q02, Q03, Q04, Q05}
//import Assignment03.Q02.{firstNo, maximum, minimum, nextValue, secondNo}
//import Assignment03.Q04.fzero
import Assignment03.Q03.product
import Assignment03.Q01.maxNo

import org.junit.Assert.assertEquals




class TestCase {

  @org.junit.Test
  def q01(): Unit = {
    val expected: Int = 66
    val actual: Int = Q01.maxInTuple((33,6,66), maxNo)
    assertEquals(expected,actual)
  }



  @org.junit.Test
  def q021(): Unit = {
    val expected : Int = 23
    val actual : Int = Q02.maximum(20,23)
    assertEquals(expected,actual)
  }
  def q022(): Unit = {
    val expected : Int = 1
    val actual : Int = Q02.minimum(20,1)
    assertEquals(expected,actual)
  }
  def q023(): Unit = {
    val expected : Int = 1
    val actual : Int = Q02.nextValue(1,2)
    assertEquals(expected,actual)
  }




  @org.junit.Test
  def q03(): Unit = {
    val expected : Int = 27
    val actual : Int = Q03.func(9,product)
    assertEquals(expected,actual)
  }




  @org.junit.Test
  def q04(): Unit = {
    val expected: Int = 20
    val actual: Int = Q04.fzero(20, i => i*10)
    assertEquals(expected,actual)
  }




  @org.junit.Test
  def q05(): Unit = {
    val expected : String = "Hello Scala"
    val actual: String = Q05.conditional[String]( "Hello Scala", _.length<4,_.reverse)
    assertEquals(expected,actual)
  }


}
