package Assignment03

object Q04 extends App {
  def fzero( x: Int, f:Int=> Unit): Int = {
    f(x*10) ;x
  }

  //fzero(2, i => println(i*10))

}
