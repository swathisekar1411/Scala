
import Functions.Functiionsinsc
import org.junit.Assert.assertEquals
import scala.collection.mutable.ListBuffer


class Testcase {

  @org.junit.Test
  def test1(): Unit = {
    val expected: Int = 9
    val actual: Int = Functiionsinsc.count(List(1, 2, 3, 4, 5, 6, 7, 8, 9))
    assertEquals(expected, actual)
  }


  @org.junit.Test
  def test2(): Unit = {
    val expected: Unit = 7

    val actual: Unit = Functiionsinsc.sortArray1(Array(-8, 2, 5, -1, 8, 9))

    assertEquals(expected, actual)
  }

  @org.junit.Test
  def test3: Unit = {
    val expected: List[Int] = List(1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4)
    val actual: List[Int] = Functiionsinsc.Extendlist(4, List(1, 2, 3, 4))
    assertEquals(expected, actual)
  }


  @org.junit.Test
  def test4: Unit = {
    val expected: Unit = ListBuffer
    val actual: Unit = Functiionsinsc.FFunctio(List(5, 7, 2, 9))
    assertEquals(expected, actual)
  }

  @org.junit.Test
  def test5(): Unit = {

    val expected: List[Int] = List(1, 5, 6, 7, 1, 10)
    val actual: List[Int] = Functiionsinsc.absv(List(1, 5, 6, 7, -1, -10))
    assertEquals(expected, actual)
  }


  @org.junit.Test
  def test6(): Unit = {
    val expected: Int = 15
    val actual: Int = Functiionsinsc.maxDiff(Array(5, -4, 6, 7, 11, -3))
    assertEquals(expected, actual)
  }

  @org.junit.Test
  def test7(): Unit = {
    val expected: String = Array(21, 21, 21, 21, 21, -1, 17, -1, -1).mkString(",")
    val actual: String = Functiionsinsc.replace(Array(9, 5, 8, 4, -10, 21, 6, 17, 11))
    assertEquals(expected, actual)
  }


}













