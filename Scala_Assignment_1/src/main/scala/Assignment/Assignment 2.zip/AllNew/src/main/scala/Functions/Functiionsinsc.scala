package Functions

import scala.collection.mutable.ListBuffer

  object Functiionsinsc extends App {

    //1.
    def count(list: List[Int]): Int = {
      list.indexOf(list.last) + 1

    }

    //2.


    def sortArray1(array: Array[Int]): Unit = {

      val sortxArray1 = array.sorted

      val sortedArray1: Array[Int] = sortxArray1
      sortedArray1.foreach(println)
      val sortedSize = sortedArray1.length
      val maxNo = sortedArray1(sortedSize - 1)
      val secMaxNo = sortedArray1(sortedSize - 2)
      val finalProduct = maxNo * secMaxNo
      //println(finalProduct)
    }
      //3.
      def Extendlist(Mul: Int, list: List[Int]): List[Int] =
        list.flatMap(List.fill(Mul)(_))


      for (x <- Extendlist(4,List(1,2,3,4)))
        println(x)

      //4.
      def FFunctio(list: List[Int]): Unit = {
        val FFunctio = list.length

        val listnew = new ListBuffer[Int]
        for (x <- 1 to FFunctio) {
          if (x % 2 != 0) {
            listnew += list(x)
          }
          //println(listnew)
        }
      }


//5.
def absv(list: List[Int]): List[Int] = {
      list.map(math.abs)

    }

    for (x <- absv(List(2,3,4,7,-10,6))) {
      println(x)
    }


    //6.

    def maxDiff(arr:Array[Int]):Int = {
      var maxDiff = 0
      val len = arr.length
      for(i <- 0 to len-1){
        for(j <- i+1 to len-1){
          if(arr(i)<arr(j) && (arr(i)-arr(j)).abs>maxDiff) maxDiff = (arr(i)-arr(j)).abs
        }
      }
      maxDiff
    }







    //7.

    def replace (array: Array [Int]): String = {
      val len = array.length
      var max = 0
      for (i <- (len - 1) to 0 by -1 ) {
        if (max < array(i)) {
          max = array(i)
          array(i) = -1
        }
        else {
          array(i) = max
        }
      }
      array.mkString(",")
    }

    }





















